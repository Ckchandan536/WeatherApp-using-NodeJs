
       const currDate = document.getElementById("date");
    //    currDate.style.color = "red";
       
       let weathericon = document.getElementById("weathericon");

       const tempStatus = "{%tempstatus}";

    // condition to check sunny or cloud
    if (tempStatus = "Sunny") {
        weathericon.innerHTML = 
        "<i class='fas fa-sun' style ='color: #eccc68;'></i>";
    } 
    else if (tempStatus = "Clouds") {
        weathericon.innerHTML = 
        "<i class='fas fa-cloud' style ='color: #f1f2f6;'></i>";
    }
     else if (tempStatus = "Rainy") {
        weathericon.innerHTML = 
        "<i class='fas fa-cloud-rain' style ='color: #a4b0be;'></i>";
    }
     else  {
        weathericon.innerHTML = 
        "<i class='fas fa-cloud' style ='color: #44c3de;'></i>";
    }
    //    featching date  and time
    const getCurrentDay = () => {
        var weekday = new Array(7);
        weekday[0] = "Sun";
        weekday[1] = "Mon";
        weekday[2] = "Tue";
        weekday[3] = "Wed";
        weekday[4] = "Thur";
        weekday[5] = "Fri";
        weekday[6] = "Sat";
        let currentTime = new Date();
        // to get current Date
        //console.log(CureentTime.getDay()); 
        // console.log(weekday[0]CureentTime.getDay());just change it to below one
        
        // it will give us numeric value from 0 to 6 
        //its totaly depends on us how to change to day in words. // we will use arrays
        // console.log(weekday[CureentTime.getDay()]);
        let day = weekday[currentTime.getDay()];
        return day;
    };

    const getCurrentTime = () => {
        // var months = [
        // 'January', // 1 array = 0
        // 'February', // 2 array = 1
        // 'March', // 3
        // 'April', // 4
        // 'May', // 5
        // 'June', // 6
        // 'July', // 7
        // 'August', //8 
        // 'September', //9 
        // 'October', // 10
        // 'November', // 11
        // 'December'// 12
        // ]
        var months = [
        "Jan", 
        "Feb", 
        "Mar", 
        "Apr", 
        "May", 
        "Jun", 
        "Jul",
        "Aug", 
        "Sep", 
        "Oct", 
        "Nov", 
        "Dec",
    ];
        var now = new Date();
        var date = now.getDate();
        // var Month = Now.getMonth() +1; // it gives actual data 0; so 0 does't exit in month so +1 is add.
        var month = months[now.getMonth() + 1];
        // var Year = Now.getFullYear(); // no needed
        // console.log(month + "/" + day + "/" + year); // year is not need + "/" + year
        // Time
        let hours = now.getHours();
        let mins = now.getMinutes();
        // define AM or PM
        let periods = "AM";
        if (hours > 11) {
            periods ="PM";
            if (hours > 12) hours -= 12;  // we want 1:30 PM not 13:30 PM
        }
        // min is less than 10 , it must comes with 0 behined it means 10Hr:09Min
        if (mins < 10) {
            mins = "0" + mins;
        }
        // console.log(Month + "/" + Day); // => till nowit will show in numeric but we need in words
        // for that we write month in array in over call back function above. var months = []
        return `${date} ${month} | ${hours}:${mins}${periods}`;
        };
      currDate.innerHTML = getCurrentDay() + " | " + getCurrentTime();
  