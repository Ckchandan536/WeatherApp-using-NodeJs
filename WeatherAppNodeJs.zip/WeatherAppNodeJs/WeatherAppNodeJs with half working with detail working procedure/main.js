//require('dotenv').config();
// fs is inbuilt package
const http = require("http");
const fs = require("fs");

const homeFile = fs.readFileSync("home.html", "utf-8");

const replaceVal = (tempval, orgval) => {
    let temperature = tempval.replace("{%tempval%}", orgVal.main.temp);
    temperature = tempval.replace("{%tempmin%}", orgVal.main.temp_min);
    temperature = tempval.replace("{%tempmax%}", orgVal.main.temp_max);
    temperature = tempval.replace("{%location%}", orgVal.name);
    temperature = tempval.replace("{%country%}", orgVal.sys.country);
    temperature = tempval.replace("{%tempstatus%}", orgVal.weather[0].main);
    return temperature;
};

// create server using req, res and [ npm requests or routing] 
// we are using npm => requests package is not inbuilt so we need to {install npm i requests}
const server = http.createServer((req, res) => {
    // requesting for home page
    if (req.url == "/") {
        // var requests = require("requests"); // place below the const fs
        // copied from https://www.npmjs.com/package/requests
        requests(
            //`http://api.openweathermap.org/data/2.5/weather?q=Pune&units=metric&appid=${process.env.APPID}`
             'https://api.openweathermap.org/data/2.5/weather?q=Jamshedpur&units=metric&appid=1b6fbaf8ced49d8edc2907cd1fe5c991', 
            // api link
            // https://api.openweathermap.org/data/2.5/weather?q={YOUR CITY NAME}&units=metric&appid=1b6fbaf8ced49d8edc2907cd1fe5c991
        )
        .on("data", (chunk) => {
            const objdata = JSON.parse(chunk);
            const arrData = [objdata];
          //console.log(arrData);
          //console.log(arrData[0].main.temp);
          const realTimeData = arrData.map((val) => replaceVall(homeFile, val).join(""));
            // console.log(val.main);
            res.write(realTimeData);
            // console.log("realTimeData");
        })
        .on("end", (err) => {
          if (err) return console.log("connection closed due to errors", err);
          // console.log('end');
          res.end();
    });
} else {
    res.end("File not found");
}
});
// listen the server then only data will shown in terminal
server.listen(8000, "127.0.0.1");
